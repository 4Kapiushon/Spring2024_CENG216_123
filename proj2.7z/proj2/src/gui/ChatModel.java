package gui;

/**
 * Created by clay on 8/7/16.
 */
public class ChatModel {

    int PORT = 4444;



}
