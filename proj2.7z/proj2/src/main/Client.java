package main;

/**
 * GUI chat client runner.
 */
public class Client {

    /**
     * Start a GUI chat client.
     */
    public static void main(String[] args) {
        // YOUR CODE HERE
        // It is not required (or recommended) to implement the client in
        // this runner class.
    }
}
