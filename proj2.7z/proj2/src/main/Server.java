package main;

/**
 * Chat server runner.
 */
public class Server {

    /**
     * Start a chat server.
     */
    public static void main(String[] args) {
        // YOUR CODE HERE
        // It is not required (or recommended) to implement the server in
        // this runner class.
    }
}
